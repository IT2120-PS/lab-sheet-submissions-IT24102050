setwd("C:\\Users\\roshe\\Downloads\\IT24102050_Lab9")


y<-rnorm(25,mean= 45,sd= 2)
y


t.test(y, mu= 46 , alternative = "less")