setwd("C:\\Users\\IT24102050\\Downloads\\IT24102050")

#Question 1
#Bonomial Distribution
#Here , random variable X has binomial distribution with n=50 and p =0.85

1-pbinom(46,50,0.85,lower.tail=TRUE)


#Question 2 ,(1)
#Poisson distribution
#Number of customer calls received by a call center per hour

#Question 2 , (2)
#Poisson distribution
#Here, random variable X has poisson distribution with lambda=12

dpois(15,12)