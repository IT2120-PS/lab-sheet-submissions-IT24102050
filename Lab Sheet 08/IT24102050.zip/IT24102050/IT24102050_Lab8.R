setwd("C:\\Users\\roshe\\Desktop\\IT24102050")

data<-read.table("Exercise - LaptopsWeights.txt", header =TRUE)

fix(data)

attach(data)

#Question 1
popmn<-mean(Weight.kg.)
popmn

popsd <- sqrt(sum((Weight.kg. - popmn)^2) / length(Weight.kg.))
popsd


#Question 2
samples<-c()
n<-c()


for(i in 1:25){
  s<-sample(Weight.kg.,6,replace=TRUE)
  samples<-cbind(samples,s)
  n<c(n,paste('S',i))
}

colnames(samples) =n

s.mean<-apply(samples,2,mean)
s.sd<-apply(samples,2,sd)


s.mean
s.sd

#Question 3
samplemean<-mean(s.mean)
samplemean

samplesd<-sd(s.mean)
samplesd


#comparing 
popmn
samplemean

#The mean of the sample means is approximately equal to the true mean

popsd
samplesd

truesd <- popsd / sqrt(6)
truesd
samplesd

